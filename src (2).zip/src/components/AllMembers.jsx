import GroupMembers from "./GroupMembers";
import ExternalMembers from "./ExternalMembers";
import UserPicker from "./UserPicker";

export default function AllMembers({
  members,
  externalMembers,
  canManage,
  onAddInternal,
  onRemoveInternal,
  onAddExternal,
  onRemoveExternal
}) {
  return (
    <div>
      {canManage && (
        <div style={{ marginBottom: 12 }}>
          <UserPicker onSelect={onAddInternal} placeholder="Ajouter un membre interne (username / email)" />
        </div>
      )}
      <GroupMembers members={members} canManage={canManage} onRemove={onRemoveInternal} />

      <hr style={{ margin: "24px 0" }} />

      {canManage && (
        <div style={{ marginBottom: 12 }}>
          <UserPicker onSelect={onAddExternal} placeholder="Ajouter un membre externe (prénom/nom)" />
        </div>
      )}
            <ExternalMembers
        groupId={groupId}
        loader={loader}
        api={{
          listExternalMembers: onListExternal,
          addExternalMember: onAddExternal,
          deleteExternalMember: onRemoveExternal
        }}
        />
    </div>
  );
}
